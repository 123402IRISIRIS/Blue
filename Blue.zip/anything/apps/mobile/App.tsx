import { App } from 'expo-router/build/qualified-entry';

export default App