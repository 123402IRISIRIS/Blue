export default function AnythingMenu() {
  return null
}
