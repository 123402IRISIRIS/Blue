"use client";

import { useState, useRef, useEffect } from "react";
import {
  Send,
  Smile,
  Image as ImageIcon,
  Sparkles,
  AlertTriangle,
  Phone,
  X,
  Bell,
  User,
} from "lucide-react";

const EMOJI_CATEGORIES = {
  "😊 Smileys": [
    "😀",
    "😃",
    "😄",
    "😁",
    "😆",
    "😅",
    "🤣",
    "😂",
    "🙂",
    "🙃",
    "😉",
    "😊",
    "😇",
    "🥰",
    "😍",
    "🤩",
    "😘",
    "😗",
    "😚",
    "😙",
    "🥲",
    "😋",
    "😛",
    "😜",
    "🤪",
    "😝",
    "🤑",
    "🤗",
  ],
  "👋 Gestures": [
    "👋",
    "🤚",
    "🖐️",
    "✋",
    "🖖",
    "👌",
    "🤌",
    "🤏",
    "✌️",
    "🤞",
    "🤟",
    "🤘",
    "🤙",
    "👈",
    "👉",
    "👆",
    "🖕",
    "👇",
    "☝️",
    "👍",
    "👎",
    "✊",
    "👊",
    "🤛",
    "🤜",
    "👏",
    "🙌",
  ],
  "❤️ Hearts": [
    "❤️",
    "🧡",
    "💛",
    "💚",
    "💙",
    "💜",
    "🖤",
    "🤍",
    "🤎",
    "💔",
    "❣️",
    "💕",
    "💞",
    "💓",
    "💗",
    "💖",
    "💘",
    "💝",
    "💟",
  ],
  "🎉 Activities": [
    "⚽",
    "🏀",
    "🏈",
    "⚾",
    "🥎",
    "🎾",
    "🏐",
    "🏉",
    "🥏",
    "🎱",
    "🪀",
    "🏓",
    "🏸",
    "🏒",
    "🏑",
    "🥍",
    "🏏",
    "🪃",
    "🥅",
    "⛳",
    "🪁",
    "🏹",
    "🎣",
    "🤿",
    "🥊",
    "🥋",
    "🎽",
    "🛹",
    "🛼",
  ],
  "🍕 Food": [
    "🍕",
    "🍔",
    "🍟",
    "🌭",
    "🍿",
    "🧈",
    "🧂",
    "🥚",
    "🍳",
    "🧇",
    "🥞",
    "🧈",
    "🍞",
    "🥐",
    "🥨",
    "🥯",
    "🥖",
    "🧀",
    "🥗",
    "🍿",
    "🧈",
    "🥓",
    "🥩",
    "🍗",
    "🍖",
  ],
};

export default function ChatWindow({ messages, setMessages, onClearChat }) {
  const [messageText, setMessageText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [crisisDetected, setCrisisDetected] = useState(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showGifPicker, setShowGifPicker] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [gifs, setGifs] = useState([]);
  const [gifSearchQuery, setGifSearchQuery] = useState("");
  const messagesEndRef = useRef(null);
  const emojiPickerRef = useRef(null);
  const gifPickerRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Close emoji/GIF picker when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        emojiPickerRef.current &&
        !emojiPickerRef.current.contains(event.target)
      ) {
        setShowEmojiPicker(false);
      }
      if (
        gifPickerRef.current &&
        !gifPickerRef.current.contains(event.target)
      ) {
        setShowGifPicker(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Search GIFs from Tenor
  const searchGifs = async (query) => {
    if (!query.trim()) {
      query = "trending";
    }

    try {
      const response = await fetch(
        `https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(query)}&key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&limit=20`,
      );
      const data = await response.json();
      setGifs(data.results || []);
    } catch (error) {
      console.error("Error fetching GIFs:", error);
      setGifs([]);
    }
  };

  useEffect(() => {
    if (showGifPicker) {
      searchGifs("excited happy");
    }
  }, [showGifPicker]);

  const handleSendMessage = async (content = null, isGif = false) => {
    const finalContent = content || messageText.trim();
    if (!finalContent) return;

    const userMessage = {
      role: "user",
      content: finalContent,
      timestamp: new Date().toISOString(),
      isGif: isGif,
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setMessageText("");
    setShowEmojiPicker(false);
    setShowGifPicker(false);
    setIsLoading(true);

    try {
      // Crisis detection
      if (!isGif) {
        try {
          const crisisCheck = await fetch("/api/crisis-detection", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: finalContent,
              userIp: "user-session",
            }),
          });

          if (crisisCheck.ok) {
            const crisisData = await crisisCheck.json();
            if (
              crisisData.isCrisis &&
              (crisisData.riskLevel === "high" ||
                crisisData.riskLevel === "severe")
            ) {
              const alertResponse = await fetch("/api/get-crisis-resources", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
              });

              if (alertResponse.ok) {
                const alertData = await alertResponse.json();
                setCrisisDetected({
                  ...crisisData,
                  nearestCrisisLine: alertData.crisisLine,
                });
              }
            }
          }
        } catch (error) {
          console.error("Crisis detection failed:", error);
        }
      }

      // Get Blue's response
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: updatedMessages }),
      });

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`);
      }

      const data = await response.json();
      const assistantMessage = {
        role: "assistant",
        content: data.message,
        timestamp: new Date().toISOString(),
      };

      setMessages([...updatedMessages, assistantMessage]);
    } catch (error) {
      console.error("Error sending message:", error);
      const errorMessage = {
        role: "assistant",
        content: "Sorry, I encountered an error. Please try again.",
        timestamp: new Date().toISOString(),
        isError: true,
      };
      setMessages([...updatedMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmojiSelect = (emoji) => {
    setMessageText(messageText + emoji);
    setShowEmojiPicker(false);
  };

  const handleGifSelect = (gifUrl) => {
    handleSendMessage(gifUrl, true);
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const MessageBubble = ({ message }) => {
    const isUser = message.role === "user";

    return (
      <div
        className={`flex items-start gap-3 mb-6 ${isUser ? "flex-row-reverse" : ""}`}
      >
        <div
          className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${
            isUser
              ? "bg-gradient-to-br from-[#3D9DF6] to-[#2563EB]"
              : "bg-gradient-to-br from-[#7A5AF8] to-[#9F7AEA]"
          }`}
        >
          <span className="text-white font-poppins font-semibold text-sm">
            {isUser ? "Y" : "B"}
          </span>
        </div>

        <div className="flex-1 max-w-[80%]">
          <div
            className={`flex items-baseline gap-2 mb-1 ${isUser ? "flex-row-reverse" : ""}`}
          >
            <span className="font-poppins font-medium text-white text-sm">
              {isUser ? "You" : "Blue"}
            </span>
            <span className="font-poppins text-white text-opacity-50 text-xs">
              {new Date(message.timestamp).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          </div>

          {message.isGif ? (
            <img
              src={message.content}
              alt="GIF"
              className="rounded-lg max-w-xs"
              style={{ maxHeight: "300px" }}
            />
          ) : (
            <div
              className={`font-poppins text-white text-sm leading-relaxed whitespace-pre-wrap ${
                message.isError ? "text-[#EF4444]" : ""
              }`}
            >
              {message.content}
            </div>
          )}
        </div>
      </div>
    );
  };

  const CrisisAlert = ({ crisis }) => {
    return (
      <div className="mx-4 mb-4 p-4 bg-gradient-to-r from-[#dc2626] to-[#b91c1c] rounded-lg border border-[#ef4444]">
        <div className="flex items-start gap-3">
          <AlertTriangle size={24} className="text-white flex-shrink-0 mt-1" />
          <div className="flex-1">
            <h4 className="font-poppins font-semibold text-white text-base mb-2">
              🆘 We're Here to Help
            </h4>
            <p className="font-poppins text-white text-sm mb-3">
              I've detected that you might be going through a difficult time.
              Your safety is important. Crisis support services have been
              notified and help is available 24/7.
            </p>
            {crisis.nearestCrisisLine && (
              <div className="bg-white bg-opacity-20 rounded-lg p-3 mb-3">
                <div className="flex items-center gap-2 mb-2">
                  <Phone size={16} className="text-white" />
                  <span className="font-poppins font-semibold text-white text-sm">
                    Crisis Support Near You
                  </span>
                </div>
                <p className="font-poppins text-white text-sm">
                  <strong>{crisis.nearestCrisisLine.service}</strong>
                </p>
                <p className="font-poppins text-white text-lg font-bold mt-1">
                  {crisis.nearestCrisisLine.phone}
                </p>
                <p className="font-poppins text-white text-xs opacity-80 mt-1">
                  Available {crisis.nearestCrisisLine.hours || "24/7"} •{" "}
                  {crisis.nearestCrisisLine.country}
                </p>
              </div>
            )}
            <p className="font-poppins text-white text-xs opacity-90">
              💙 You're not alone. These services are free, confidential, and
              staffed by people who care.
            </p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full w-full max-w-5xl mx-auto bg-[#0F0F14] rounded-2xl overflow-hidden shadow-2xl border border-[#262630]">
      {/* WhatsApp-Style Header */}
      <div className="flex items-center justify-between px-5 py-4 bg-[#1A1B25] border-b border-[#262630]">
        {/* Left: Blue Logo and Name */}
        <div className="flex items-center gap-3">
          <div className="relative w-11 h-11">
            <div
              className="absolute inset-0 bg-gradient-to-br from-[#3D9DF6] to-[#2563EB] shadow-lg"
              style={{
                borderRadius: "63% 37% 54% 46% / 55% 48% 52% 45%",
                animation: "blob 4s ease-in-out infinite",
              }}
            >
              <div className="w-full h-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">💙</span>
              </div>
            </div>
          </div>
          <div>
            <h1 className="font-poppins font-semibold text-white text-lg">
              Blue
            </h1>
            <p className="font-poppins text-[#10B981] text-xs font-medium flex items-center gap-1">
              <span className="w-2 h-2 bg-[#10B981] rounded-full"></span>
              Online
            </p>
          </div>
        </div>

        {/* Right: Profile and Notification Icons */}
        <div className="flex items-center gap-2">
          <a
            href="/account/profile"
            className="p-2.5 rounded-full hover:bg-[#262630] transition-all duration-200 group"
            title="Profile"
          >
            <User
              size={22}
              className="text-white text-opacity-70 group-hover:text-opacity-100 transition-opacity"
            />
          </a>
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2.5 rounded-full hover:bg-[#262630] transition-all duration-200 group"
            title="Notifications"
          >
            <Bell
              size={22}
              className="text-white text-opacity-70 group-hover:text-opacity-100 transition-opacity"
            />
            {/* Active Notification Dot */}
            <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#10B981] rounded-full border-2 border-[#1A1B25]"></span>
          </button>
        </div>
      </div>

      {/* Crisis Alert */}
      {crisisDetected && <CrisisAlert crisis={crisisDetected} />}

      {/* Messages Area - WhatsApp Style */}
      <div
        className="flex-1 overflow-y-auto p-6 space-y-1"
        style={{
          backgroundImage:
            "radial-gradient(circle at 20% 50%, rgba(122, 90, 248, 0.03) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(61, 157, 246, 0.03) 0%, transparent 50%)",
        }}
      >
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full">
            <div className="w-24 h-24 bg-gradient-to-br from-[#7A5AF8] to-[#9F7AEA] rounded-full flex items-center justify-center mb-6 shadow-xl">
              <Sparkles size={40} className="text-white" />
            </div>
            <h2 className="font-poppins font-semibold text-white text-2xl mb-3 text-center">
              Hi, I'm Blue! 👋
            </h2>
            <p className="font-poppins text-white text-opacity-60 text-center max-w-md text-sm">
              I'm here to listen and support you. Talk to me about anything -
              your feelings, your day, or whatever's on your mind. You're not
              alone. 💙
            </p>
          </div>
        ) : (
          <>
            {messages.map((message, index) => (
              <MessageBubble key={index} message={message} />
            ))}
            {isLoading && (
              <div className="flex items-start gap-3 mb-6">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#7A5AF8] to-[#9F7AEA] flex items-center justify-center">
                  <span className="text-white font-poppins font-semibold text-sm">
                    B
                  </span>
                </div>
                <div className="flex-1">
                  <span className="font-poppins text-[#7A5AF8] text-sm">
                    Blue is typing<span className="typing-dots">...</span>
                  </span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input Area - WhatsApp Style */}
      <div className="p-4 bg-[#1A1B25] border-t border-[#262630]">
        <div className="bg-[#262630] rounded-full px-4 py-3 flex items-center gap-3">
          {/* Left Icons */}
          <div className="flex items-center gap-2 relative">
            {/* Emoji Picker Button */}
            <button
              onClick={() => {
                setShowEmojiPicker(!showEmojiPicker);
                setShowGifPicker(false);
              }}
              className="text-white text-opacity-60 hover:text-opacity-100 transition-colors duration-200"
              title="Add emoji"
            >
              <Smile size={22} />
            </button>

            {/* GIF Picker Button */}
            <button
              onClick={() => {
                setShowGifPicker(!showGifPicker);
                setShowEmojiPicker(false);
              }}
              className="text-white text-opacity-60 hover:text-opacity-100 transition-colors duration-200"
              title="Add GIF"
            >
              <ImageIcon size={22} />
            </button>

            {/* Emoji Picker Popup */}
            {showEmojiPicker && (
              <div
                ref={emojiPickerRef}
                className="absolute bottom-full left-0 mb-2 bg-[#1D1D25] border border-[#3A3A3A] rounded-lg shadow-xl p-3 w-80 max-h-80 overflow-y-auto z-50"
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-poppins font-semibold text-white text-sm">
                    Pick an emoji
                  </h3>
                  <button
                    onClick={() => setShowEmojiPicker(false)}
                    className="text-white text-opacity-60 hover:text-opacity-100"
                  >
                    <X size={16} />
                  </button>
                </div>
                {Object.entries(EMOJI_CATEGORIES).map(([category, emojis]) => (
                  <div key={category} className="mb-3">
                    <p className="font-poppins text-white text-opacity-60 text-xs mb-2">
                      {category}
                    </p>
                    <div className="grid grid-cols-8 gap-1">
                      {emojis.map((emoji) => (
                        <button
                          key={emoji}
                          onClick={() => handleEmojiSelect(emoji)}
                          className="w-8 h-8 flex items-center justify-center hover:bg-[#262630] rounded transition-colors text-xl"
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* GIF Picker Popup */}
            {showGifPicker && (
              <div
                ref={gifPickerRef}
                className="absolute bottom-full left-0 mb-2 bg-[#1D1D25] border border-[#3A3A3A] rounded-lg shadow-xl p-3 w-96 max-h-96 overflow-hidden z-50"
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-poppins font-semibold text-white text-sm">
                    Pick a GIF
                  </h3>
                  <button
                    onClick={() => setShowGifPicker(false)}
                    className="text-white text-opacity-60 hover:text-opacity-100"
                  >
                    <X size={16} />
                  </button>
                </div>
                <input
                  type="text"
                  placeholder="Search GIFs..."
                  value={gifSearchQuery}
                  onChange={(e) => {
                    setGifSearchQuery(e.target.value);
                    searchGifs(e.target.value);
                  }}
                  className="w-full bg-[#262630] text-white placeholder-gray-400 rounded-lg px-3 py-2 mb-3 font-poppins text-sm focus:outline-none focus:ring-2 focus:ring-[#7A5AF8]"
                />
                <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto">
                  {gifs.map((gif) => (
                    <button
                      key={gif.id}
                      onClick={() =>
                        handleGifSelect(gif.media_formats.tinygif.url)
                      }
                      className="rounded-lg overflow-hidden hover:opacity-80 transition-opacity"
                    >
                      <img
                        src={gif.media_formats.tinygif.url}
                        alt={gif.content_description || "GIF"}
                        className="w-full h-32 object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Text Input */}
          <input
            type="text"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Talk to me, I am Blue, your friend"
            className="flex-1 bg-transparent text-white placeholder-gray-400 focus:outline-none font-poppins text-sm"
            disabled={isLoading}
          />

          {/* Send Button */}
          <button
            onClick={() => handleSendMessage()}
            disabled={!messageText.trim() || isLoading}
            className={`p-2 rounded-full transition-all duration-200 ${
              messageText.trim() && !isLoading
                ? "bg-gradient-to-r from-[#614BFF] to-[#8360FF] hover:from-[#553DE8] hover:to-[#7352E8] shadow-lg"
                : "bg-gray-700 cursor-not-allowed opacity-40"
            }`}
          >
            <Send size={18} className="text-white" />
          </button>
        </div>
      </div>

      <style jsx>{`
        .font-poppins {
          font-family: "Poppins", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }

        .typing-dots {
          display: inline-block;
          animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes pulse {
          0%,
          100% {
            opacity: 1;
          }
          50% {
            opacity: 0.5;
          }
        }

        .overflow-y-auto::-webkit-scrollbar {
          width: 6px;
        }

        .overflow-y-auto::-webkit-scrollbar-track {
          background: transparent;
        }

        .overflow-y-auto::-webkit-scrollbar-thumb {
          background: #3a3a3a;
          border-radius: 3px;
        }

        .overflow-y-auto::-webkit-scrollbar-thumb:hover {
          background: #4a4a4a;
        }
      `}</style>
    </div>
  );
}
