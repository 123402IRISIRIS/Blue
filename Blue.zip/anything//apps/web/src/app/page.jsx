"use client";

import { useState } from "react";
import ChatWindow from "../components/ChatWindow";

export default function HomePage() {
  const [messages, setMessages] = useState([]);

  const handleClearChat = () => {
    if (
      confirm("Are you sure you want to clear your chat history with Blue?")
    ) {
      setMessages([]);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-[#0A0A0F] via-[#0F0F14] to-[#1A1B25] p-4 md:p-6">
      <div className="w-full h-[calc(100vh-2rem)] md:h-[calc(100vh-3rem)] max-w-6xl">
        <ChatWindow
          messages={messages}
          setMessages={setMessages}
          onClearChat={handleClearChat}
        />
      </div>
    </div>
  );
}
