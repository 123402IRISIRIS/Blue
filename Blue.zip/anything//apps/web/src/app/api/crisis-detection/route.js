export async function POST(request) {
  try {
    const body = await request.json();
    const { message, userIp } = body;

    if (!message) {
      return Response.json({ error: "Message is required" }, { status: 400 });
    }

    // Use ChatGPT to analyze the message for crisis indicators
    const analysisResponse = await fetch(
      "/integrations/chat-gpt/conversationgpt4",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content: `You are a mental health crisis detection system for a teen support companion called Blue. Analyze the following message for signs of:
- Suicide ideation or intent
- Self-harm thoughts or behaviors
- Severe depression or hopelessness
- Immediate danger to self or others
- Extreme distress or crisis

Respond with a JSON object containing:
{
  "isCrisis": true/false,
  "riskLevel": "none" | "low" | "moderate" | "high" | "severe",
  "concerns": ["list of specific concerns identified"],
  "reasoning": "brief explanation"
}

Be sensitive but thorough. Even subtle cries for help should be taken seriously.`,
            },
            {
              role: "user",
              content: message,
            },
          ],
        }),
      },
    );

    if (!analysisResponse.ok) {
      console.error("Crisis detection analysis failed");
      return Response.json({ isCrisis: false, riskLevel: "none" });
    }

    const analysisData = await analysisResponse.json();
    let analysis;

    try {
      // Extract JSON from the response
      const content = analysisData.choices[0].message.content;
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysis = JSON.parse(jsonMatch[0]);
      } else {
        analysis = { isCrisis: false, riskLevel: "none" };
      }
    } catch (parseError) {
      console.error("Failed to parse crisis analysis:", parseError);
      analysis = { isCrisis: false, riskLevel: "none" };
    }

    // If crisis is detected, trigger the alert system
    if (
      analysis.isCrisis &&
      (analysis.riskLevel === "high" || analysis.riskLevel === "severe")
    ) {
      try {
        await fetch("/api/send-crisis-alert", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            message,
            userIp,
            analysis,
          }),
        });
      } catch (alertError) {
        console.error("Failed to send crisis alert:", alertError);
      }
    }

    return Response.json(analysis);
  } catch (error) {
    console.error("Error in crisis detection:", error);
    return Response.json(
      { error: "Failed to analyze message", details: error.message },
      { status: 500 },
    );
  }
}
