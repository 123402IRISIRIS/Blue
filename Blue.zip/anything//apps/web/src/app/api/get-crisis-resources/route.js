import sql from "@/app/api/utils/sql";

async function getLocationFromIP(ip) {
  try {
    const response = await fetch(`https://ipapi.co/${ip}/json/`);
    if (!response.ok) {
      throw new Error("Geolocation failed");
    }
    const data = await response.json();
    return {
      country: data.country_name,
      countryCode: data.country_code,
      city: data.city,
      region: data.region,
      latitude: data.latitude,
      longitude: data.longitude,
    };
  } catch (error) {
    console.error("Error getting location from IP:", error);
    return null;
  }
}

function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

async function findNearestCrisisLine(latitude, longitude, countryCode) {
  try {
    const countryLines = await sql`
      SELECT * FROM crisis_lines 
      WHERE country_code = ${countryCode}
      ORDER BY id
      LIMIT 5
    `;

    if (countryLines.length > 0) {
      return countryLines[0];
    }

    const allLines = await sql`
      SELECT * FROM crisis_lines 
      WHERE latitude IS NOT NULL AND longitude IS NOT NULL
    `;

    let nearest = null;
    let minDistance = Infinity;

    for (const line of allLines) {
      const distance = calculateDistance(
        latitude,
        longitude,
        parseFloat(line.latitude),
        parseFloat(line.longitude),
      );
      if (distance < minDistance) {
        minDistance = distance;
        nearest = line;
      }
    }

    return nearest;
  } catch (error) {
    console.error("Error finding nearest crisis line:", error);
    return {
      country: "International",
      phone_number: "988 (US) or local emergency services",
      service_name: "Crisis Support",
      hours: "24/7",
    };
  }
}

export async function POST(request) {
  try {
    // Get client IP from headers (this would be populated by your hosting provider)
    const forwardedFor = request.headers.get("x-forwarded-for");
    const realIp = request.headers.get("x-real-ip");
    const clientIp = forwardedFor?.split(",")[0] || realIp || "8.8.8.8";

    const location = await getLocationFromIP(clientIp);

    if (!location) {
      // Return default US crisis line if location detection fails
      return Response.json({
        crisisLine: {
          service: "National Suicide Prevention Lifeline",
          phone: "988",
          country: "United States",
          hours: "24/7",
        },
      });
    }

    const crisisLine = await findNearestCrisisLine(
      location.latitude,
      location.longitude,
      location.countryCode,
    );

    return Response.json({
      crisisLine: {
        service: crisisLine.service_name,
        phone: crisisLine.phone_number,
        country: crisisLine.country,
        hours: crisisLine.hours || "24/7",
      },
      location: `${location.city}, ${location.country}`,
    });
  } catch (error) {
    console.error("Error getting crisis resources:", error);
    return Response.json({
      crisisLine: {
        service: "National Suicide Prevention Lifeline",
        phone: "988",
        country: "United States",
        hours: "24/7",
      },
    });
  }
}
