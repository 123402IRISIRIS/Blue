import sql from "@/app/api/utils/sql";
import { sendEmail } from "@/app/api/utils/send-email";

async function getLocationFromIP(ip) {
  try {
    // Use ipapi.co for geolocation (free tier available)
    const response = await fetch(`https://ipapi.co/${ip}/json/`);
    if (!response.ok) {
      throw new Error("Geolocation failed");
    }
    const data = await response.json();
    return {
      country: data.country_name,
      countryCode: data.country_code,
      city: data.city,
      region: data.region,
      latitude: data.latitude,
      longitude: data.longitude,
    };
  } catch (error) {
    console.error("Error getting location from IP:", error);
    return null;
  }
}

function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

async function findNearestCrisisLine(latitude, longitude, countryCode) {
  try {
    // First try to find crisis lines in the same country
    const countryLines = await sql`
      SELECT * FROM crisis_lines 
      WHERE country_code = ${countryCode}
      ORDER BY id
      LIMIT 5
    `;

    if (countryLines.length > 0) {
      return countryLines[0];
    }

    // If no country-specific line, find the nearest geographically
    const allLines = await sql`
      SELECT * FROM crisis_lines 
      WHERE latitude IS NOT NULL AND longitude IS NOT NULL
    `;

    let nearest = null;
    let minDistance = Infinity;

    for (const line of allLines) {
      const distance = calculateDistance(
        latitude,
        longitude,
        parseFloat(line.latitude),
        parseFloat(line.longitude),
      );
      if (distance < minDistance) {
        minDistance = distance;
        nearest = line;
      }
    }

    return nearest;
  } catch (error) {
    console.error("Error finding nearest crisis line:", error);
    // Return a default international crisis line
    return {
      country: "International",
      phone_number: "988 (US) or local emergency services",
      service_name: "Crisis Support",
      hours: "24/7",
    };
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { message, userIp, analysis } = body;

    // Get user location from IP
    const location = await getLocationFromIP(userIp || "8.8.8.8");

    if (!location) {
      console.error("Could not determine user location");
      return Response.json({
        success: false,
        error: "Could not determine location",
      });
    }

    // Find nearest crisis line
    const crisisLine = await findNearestCrisisLine(
      location.latitude,
      location.longitude,
      location.countryCode,
    );

    // Log the distress signal in database
    const distressSignal = await sql`
      INSERT INTO distress_signals (
        user_ip, 
        user_location, 
        message_content, 
        risk_level,
        crisis_line_id
      ) VALUES (
        ${userIp},
        ${`${location.city}, ${location.region}, ${location.country}`},
        ${message},
        ${analysis.riskLevel},
        ${crisisLine.id || null}
      )
      RETURNING id
    `;

    // Prepare email content
    const emailSubject = `🚨 URGENT: Crisis Alert from Blue Teen Support`;
    const emailHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px 10px 0 0;">
          <h1 style="margin: 0; font-size: 24px;">🚨 Crisis Alert from Blue</h1>
          <p style="margin: 10px 0 0 0; opacity: 0.9;">Teen Support Companion - Immediate Attention Required</p>
        </div>
        
        <div style="background: #f7f7f7; padding: 20px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 10px 10px;">
          <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h2 style="color: #d32f2f; margin-top: 0; font-size: 18px;">⚠️ Crisis Detected</h2>
            <p style="margin: 10px 0;"><strong>Risk Level:</strong> <span style="color: #d32f2f; font-weight: bold; text-transform: uppercase;">${analysis.riskLevel}</span></p>
            <p style="margin: 10px 0;"><strong>Concerns Identified:</strong></p>
            <ul style="margin: 5px 0; padding-left: 20px;">
              ${analysis.concerns ? analysis.concerns.map((c) => `<li>${c}</li>`).join("") : "<li>General distress</li>"}
            </ul>
          </div>

          <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h3 style="color: #333; margin-top: 0; font-size: 16px;">📍 User Location</h3>
            <p style="margin: 10px 0;"><strong>IP Address:</strong> ${userIp}</p>
            <p style="margin: 10px 0;"><strong>Location:</strong> ${location.city}, ${location.region}, ${location.country}</p>
            <p style="margin: 10px 0;"><strong>Coordinates:</strong> ${location.latitude}, ${location.longitude}</p>
          </div>

          <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h3 style="color: #333; margin-top: 0; font-size: 16px;">💬 Message Content</h3>
            <p style="background: #f5f5f5; padding: 15px; border-left: 4px solid #667eea; margin: 10px 0; font-style: italic; color: #555;">
              "${message.substring(0, 500)}${message.length > 500 ? "..." : ""}"
            </p>
          </div>

          <div style="background: #e3f2fd; padding: 20px; border-radius: 8px; border-left: 4px solid #2196f3;">
            <h3 style="color: #1976d2; margin-top: 0; font-size: 16px;">📞 Nearest Crisis Line</h3>
            <p style="margin: 10px 0;"><strong>Service:</strong> ${crisisLine.service_name || "Crisis Support"}</p>
            <p style="margin: 10px 0;"><strong>Country:</strong> ${crisisLine.country}</p>
            <p style="margin: 10px 0;"><strong>Phone:</strong> <a href="tel:${crisisLine.phone_number}" style="color: #1976d2; font-size: 18px; font-weight: bold; text-decoration: none;">${crisisLine.phone_number}</a></p>
            <p style="margin: 10px 0;"><strong>Hours:</strong> ${crisisLine.hours || "Check local listings"}</p>
          </div>

          <div style="margin-top: 20px; padding: 15px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px;">
            <p style="margin: 0; color: #856404; font-weight: bold;">⚠️ This is an automated alert from Blue, a teen support companion.</p>
            <p style="margin: 10px 0 0 0; color: #856404; font-size: 14px;">Please respond immediately if you provide crisis intervention services in this region.</p>
          </div>

          <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #888;">
            <p>Alert ID: ${distressSignal[0].id} | Timestamp: ${new Date().toISOString()}</p>
            <p>Sent from: BlueAsksForHelp@gmail.com</p>
          </div>
        </div>
      </div>
    `;

    const emailText = `
URGENT: CRISIS ALERT FROM BLUE TEEN SUPPORT

Risk Level: ${analysis.riskLevel.toUpperCase()}

User Location:
- IP: ${userIp}
- Location: ${location.city}, ${location.region}, ${location.country}
- Coordinates: ${location.latitude}, ${location.longitude}

Message: "${message}"

Nearest Crisis Line:
- Service: ${crisisLine.service_name}
- Country: ${crisisLine.country}
- Phone: ${crisisLine.phone_number}
- Hours: ${crisisLine.hours}

Alert ID: ${distressSignal[0].id}
Timestamp: ${new Date().toISOString()}
    `;

    // In a production environment, you would send this to the actual crisis line email
    // For now, we'll send it to a designated alert email
    // Note: The user will need to configure Resend and verify their domain

    let emailSent = false;
    try {
      // Try to send email - this will fail if Resend is not configured
      await sendEmail({
        from: "BlueAsksForHelp@gmail.com", // Will need domain verification
        to: "crisis-alerts@example.com", // Replace with actual crisis service email
        subject: emailSubject,
        html: emailHtml,
        text: emailText,
      });

      emailSent = true;

      // Update the distress signal record
      await sql`
        UPDATE distress_signals 
        SET email_sent = true, email_sent_at = NOW()
        WHERE id = ${distressSignal[0].id}
      `;
    } catch (emailError) {
      console.error("Failed to send crisis alert email:", emailError);
      console.log("Email configuration needed. Alert logged to database.");
    }

    return Response.json({
      success: true,
      alertId: distressSignal[0].id,
      emailSent,
      crisisLine: {
        service: crisisLine.service_name,
        phone: crisisLine.phone_number,
        country: crisisLine.country,
      },
      location: `${location.city}, ${location.country}`,
    });
  } catch (error) {
    console.error("Error sending crisis alert:", error);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 },
    );
  }
}
